package application;
	
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	
	public static Stage window;
	
	public void start(Stage primaryStage) throws IOException {
		window = primaryStage;
		primaryStage.setTitle("Hospital");
		primaryStage.setResizable(false);
		
		//adding the fxml documents
		Parent root = FXMLLoader.load(getClass().getResource("AccountType.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setResizable(false);
		primaryStage.setScene(scene);
		primaryStage.show();
		
	   // root = FXMLLoader.load(getClass().getResource("Admin.fxml"));
		//Scene scene2 = new Scene(root);
		
		//adding the css file
		String css = this.getClass().getResource("application.css").toExternalForm();
		scene.getStylesheets().add(css);
		
		
	}
	
	public void changeScene(String fxml) throws IOException {

		Parent root = FXMLLoader.load(getClass().getResource(fxml));
		window.getScene().setRoot(root);
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
