package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Random;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Window;

public class AdminInsertingDoctors implements Initializable {

	@FXML
    private ChoiceBox<String> BloodGroup;

    @FXML
    private Label BloodGroupLabel;

    @FXML
    private DatePicker DateOfJoining;

    @FXML
    private Label DateOfJoiningLabel;

    @FXML
    private ChoiceBox<String> Gender;

    @FXML
    private Label GenderLabel;

    @FXML
    private TextField Password;

    @FXML
    private Label PasswordLabel;

    @FXML
    private TextField speciality;
    
    @FXML
    private Label Speciality;

    @FXML
    private TextField Username;

    @FXML
    private Label UsernameLabel;

    @FXML
    private Button Undo;

    @FXML
    private Button Delete;
    
    @FXML
    private Button NewDoctor;

    @FXML
    private Button generator;
    
    @FXML
    private Button Save;
    
    Main sc = new Main();
    
    String [] BloodType = {"A+", "B+", "AB+" ,"O+"};
    String [] gender_specific = {"M","F"};
    
    public void initialize(URL arg0, ResourceBundle arg1) {
		Gender.getItems().addAll(gender_specific);
    	BloodGroup.getItems().addAll(BloodType);
    }
    
    @FXML
    void undo(ActionEvent event) throws IOException {
    	sc.changeScene("AdminLogin.fxml");
    }
    
    @FXML
    void newDoctor(ActionEvent event) {
       BloodGroup.setValue(null);

       DateOfJoining.setValue(null);

       Gender.setValue(null);


       Password.setText("");

       Username.setText("");

       speciality.setText("");
       
       UsernameLabel.setText("");
  
       PasswordLabel.setText("");
   
       Speciality.setText("");
        
       BloodGroupLabel.setText("");
   
       GenderLabel.setText("");
       
       DateOfJoiningLabel.setText("");
    }

    @FXML
    void GeneratePassword(ActionEvent event) {
    	String Upper = "ABCDFGHIJKLMNoPQRSTUVWXZY";
    	String Lowers ="abcdefghijklmnopqrstuvwxzy";
    	String Digits = "0123456789";
    	String specialChars = "<>,.?+-_!@#$%^&*=";
    	String combination = Upper+Lowers+Digits+specialChars;
    	int len = 8;
    	char[] password = new char[len];
    	Random r = new Random();
    	for(int i=0;i<len;i++) {
    		password[i]=combination.charAt(r.nextInt(combination.length()));
    	}
    	try (Connection connection = DriverManager.getConnection(DatabaseConnection.DATABASE_URL, DatabaseConnection.DATABASE_USERNAME, DatabaseConnection.DATABASE_PASSWORD);

                PreparedStatement preparedStatement = connection.prepareStatement(DatabaseConnection.InsertingQUERY)) {
                preparedStatement.setString(1, Password.getText());
               
                ResultSet resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                	for(int i=0;i<len;i++) {
                		password[i]=combination.charAt(r.nextInt(combination.length()));
                	}
                }
            } catch (SQLException e1) {
                // print SQL exception information
            	e1.printStackTrace();
            }
    	Password.setText(password.toString());
    }
    
    @FXML
    void delete(ActionEvent event) {

    }
    
    @FXML
    public void save(ActionEvent event) throws IOException,SQLException {
    	
    	Window owner = Save.getScene().getWindow();
    	
    	CheckifAllIsEmpty();
 		CheckifOneIsEmpty();
 		RemoveLabelIfFilled();
 		
    	String username = Username.getText();
        String password = Password.getText();
        String gender = Gender.getValue().toString();
        LocalDate value = DateOfJoining. getValue();
        String dateOfJoining = value.toString();
        String bloodGroup = BloodGroup.getValue().toString();
        String Speciality = speciality.getText();
        
        DatabaseConnection jdb = DatabaseConnection.getInstance();
        
        if(CheckifAllIsEmpty() ) {//&& CheckifOneIsEmpty()
     
        	jdb.insertRec(username, password, gender, dateOfJoining, bloodGroup, Speciality);
            showAlert(Alert.AlertType.CONFIRMATION, owner, "Doctor Successfully Added!","Welcome");
     	}
     	else {
     		CheckifAllIsEmpty();
     		CheckifOneIsEmpty();
     		RemoveLabelIfFilled();
     	}
       
    }
    

    private boolean CheckifAllIsEmpty() {
    	if (Username.getText().isEmpty() && Password.getText().isEmpty() && speciality.getText().isEmpty() && Gender.getValue()==null && DateOfJoining.getValue()==null && BloodGroup.getValue()==null) {
    		UsernameLabel.setText( "Please enter the doctor's username");
        	PasswordLabel.setText("Please enter the doctor's password");
        	Speciality.setText("Please enter the doctor's speciality");
        	BloodGroupLabel.setText("Please enter the doctor's blood type");
        	GenderLabel.setText("Please enter the doctor's gender");
        	DateOfJoiningLabel.setText("Please enter the doctor's starting day"); 
        	return false;
    	}
		return true;
    }
    private boolean CheckifOneIsEmpty() {

        boolean validTextFields = true;

        if (Username.getText().isEmpty()) {
            validTextFields = false;
            UsernameLabel.setText( "Please enter the doctor's username");
        }

        if (Password.getText().isEmpty()) {
            validTextFields = false;
            PasswordLabel.setText("Please enter for the doctor a password\n or generate one");
        }
        
        if (speciality.getText().isEmpty()) {
            validTextFields = false;
            Speciality.setText("Please enter the doctor's speciality");
            
        }
        
        if (BloodGroup.getValue()==null) {
            validTextFields = false;
            BloodGroupLabel.setText("Please enter the doctor's blood type");
        }

        
        if (Gender.getValue()==null) {
            validTextFields = false;
            GenderLabel.setText("Please enter the doctor's gender");
        }

        if (DateOfJoining.getValue()==null) {
            validTextFields = false;
            DateOfJoiningLabel.setText("Please enter the doctor's starting day"); 
        }

        return validTextFields;
    }
    private boolean RemoveLabelIfFilled() {
		boolean validTextFields = true;

        if (!Username.getText().isEmpty()) {
            validTextFields = false;
            UsernameLabel.setText("");
        }

        if (!Password.getText().isEmpty()) {
            validTextFields = false;
            PasswordLabel.setText("");
        }
        
        if (!speciality.getText().isEmpty()) {
            validTextFields = false;
            Speciality.setText("");
            
        }
        
        if (BloodGroup.getValue()!=null) {
            validTextFields = false;
            BloodGroupLabel.setText("");
        }

        
        if (Gender.getValue()!=null) {
            validTextFields = false;
            GenderLabel.setText("");
            
        }

        if (DateOfJoining.getValue()!=null) {
            validTextFields = false;
            DateOfJoiningLabel.setText(""); 
        }

        return validTextFields;
	}

	private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
    
}
