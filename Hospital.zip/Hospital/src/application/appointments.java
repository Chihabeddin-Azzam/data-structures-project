package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.awt.*;

import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.input.InputMethodEvent;

	public class appointments implements Initializable{
	@FXML
    private DatePicker Day_Slot;

    @FXML
    private ChoiceBox<String> Department;

    @FXML
    private ChoiceBox<String> Doctor_name;

    @FXML
    private ChoiceBox<String> Time_Slot;

    @FXML
    private Button back;
    
    @FXML
    private Button BookAppointment;
    
   
    
    DatabaseConnection jdb = DatabaseConnection.getInstance();
    
    Main sc = new Main();
	
    String[] department = {"Neurologist", "Psychiatrist",  "Dermatology","Cardiologist", "Orthopedic"};
    String [] TimesAvailable = {"8:00 am","9:00 am","10:00 am","11:00 am","12:00 pm","1:00 pm","2:00 pm","3:00 pm","4:00 pm","5:00 pm"};

    
    
    public void initialize(URL arg0, ResourceBundle arg1) {
    	Department.setValue("None");
    	Department.getItems().addAll(department);
    	Time_Slot.getItems().addAll(TimesAvailable);
    	Department.getSelectionModel().selectedItemProperty().addListener
    	( (ObservableValue<? extends String> observable, String oldValue, String newValue) -> Doctor_name.getItems().clear());
    	Department.getSelectionModel().selectedItemProperty().addListener
    	( (ObservableValue<? extends String> observable, String oldValue, String newValue)
    			-> Doctor_name.getItems().addAll(jdb.getDoctorsNames(newValue)) );
    	
	}
    
    
	@FXML
	void Undo(ActionEvent event) throws IOException {
	sc.changeScene("Login.fxml");
	}
}
