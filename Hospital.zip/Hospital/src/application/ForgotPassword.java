package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class ForgotPassword {

    @FXML
    private Button Back;

    @FXML
    private Button ChangePassword;

    @FXML
    private TextField ConfirmPassword;

    @FXML
    private Label InvalidPasswordLabel;

    @FXML
    private Label InvalidUsernameLabel;

    @FXML
    private TextField Username;

    @FXML
    private PasswordField password;
    
    Main sc = new Main();
    
    @FXML
    void Undo(ActionEvent event) throws IOException {
    	sc.changeScene("Login.fxml");
    }

    @FXML
    void changePassword(ActionEvent event) {

    }

}
