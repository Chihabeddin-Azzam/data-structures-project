package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;

public class DoctorInsertingAppoitnments {

    @FXML
    private Button back;

    @FXML
    private DatePicker day;

    @FXML
    private Button insert;

    @FXML
    private ChoiceBox<String> time;

    Main sc = new Main();
    @FXML
    void insertingAppointments(ActionEvent event) {
    	
    }

    @FXML
    void undo(ActionEvent event) throws IOException {
    	sc.changeScene("DoctorLogin.fxml");
    }

}
