package application;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Window;

public class SignUp implements Initializable{

 
    String gender[] = {"Male", "Female"};
    
    @FXML
    private DatePicker DateOfBirth;

    @FXML
    private TextField Email;

    @FXML
    private TextField FirstName;

    @FXML
    private ChoiceBox<String> Gender;

    @FXML
    private TextField LastName;

    @FXML
    private TextField Medications;

    @FXML
    private Button Submit;

    @FXML
    private TextField Allergies;

    @FXML
    private TextField ConfirmPassword;

    @FXML
    private TextField Password;
    
    @FXML
    private Button Undo;

    Main sc = new Main();
    
    
    @FXML
    void Undo(ActionEvent event) throws IOException {
    	sc.changeScene("Login.fxml");
    }

	public void initialize(URL arg0, ResourceBundle arg1) {
		Gender.setValue("None");
		Gender.getItems().addAll(gender);
		
	}
    @FXML
    public void Submit(ActionEvent event) throws SQLException,IOException {

        Window owner = Submit.getScene().getWindow();

        System.out.println(Email.getText());
        System.out.println(Password.getText());
        
        
       
        if (Email.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                "Please enter your email id");
            return;
        }
        if (Password.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Form Error!",
                "Please enter a password");
            return;
        }

        String email = Email.getText();
        String password = Password.getText();
        String firstName = FirstName.getText();
        String lastName = LastName.getText();
        String confirmPassword = ConfirmPassword.getText();
        String gender = Gender.getValue();
        LocalDate value = DateOfBirth. getValue();
        String dateOfBirth = value.toString();
        String medications = Medications.getText();
        String allergies = Allergies.getText();
        

        DatabaseConnection jdb = DatabaseConnection.getInstance();
        jdb.insertRecord(firstName, lastName, email, password, confirmPassword, gender, dateOfBirth, medications, allergies);

        showAlert(Alert.AlertType.CONFIRMATION, owner, "Registration Successful!",
            "Welcome");
        sc.changeScene("Login.fxml");
    }

    private static void showAlert(Alert.AlertType alertType, Window owner, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.initOwner(owner);
        alert.show();
    }
}