package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodEvent;

public class AdminLogin {

    @FXML
    private Button BackButton;

    @FXML
    private Button LoginButton;

    @FXML
    private TextField Username;

    @FXML
    private PasswordField password;

    @FXML
    private Label InvalidPasswordLabel;

    @FXML
    private Label InvalidUsernameLabel;
    
    String username = "CEO";
    String pass = "0000";
    Main scene = new Main();
      @FXML
    void Login(ActionEvent event) throws IOException {
    	  if(Username.getText().toString().equals(username) && password.getText().toString().equals(pass)) {
    		  scene.changeScene("Admin.fxml");
    	  }
    	  else {
    		  InvalidUsernameLabel.setText("Invalid Username");
    		  InvalidPasswordLabel.setText("Invalid password");
    	  }
    }

    @FXML
    void Undo(ActionEvent event) throws IOException {
    	scene.changeScene("AccountType.fxml");
    }

}
